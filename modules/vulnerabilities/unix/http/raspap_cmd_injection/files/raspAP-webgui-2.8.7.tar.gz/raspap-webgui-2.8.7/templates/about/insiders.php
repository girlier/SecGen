<!-- about sponsors tab -->
<div class="tab-pane fade" id="aboutsponsors">
  <div class="row">
    <div class="col-lg-12 mt-3">
      <?php echo $sponsorsHtml; ?>
    </div>
  </div><!-- /.row -->
</div><!-- /.tab-pane | sponsors tab -->

